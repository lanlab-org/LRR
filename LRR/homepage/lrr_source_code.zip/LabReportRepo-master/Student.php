<?php
$page="student";
include 'Header.php';

?>

<br><br><br>


<div class="row" style="width:80%;margin:auto;">
   
    <div class="col-md-6">
     <h1> STUEDNT Account Created , Now you can Browse Course Portals </h1>   
    </div>
    
    
</div>




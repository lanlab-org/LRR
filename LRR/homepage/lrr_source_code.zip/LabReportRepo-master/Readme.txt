* Student Regisreation Process is now simplyfied, Student Passport/ID checking process skipped as there is no where find that information currenly. The system now checks Student Passport / National ID from users tables insead of verifying from school databse.



* 